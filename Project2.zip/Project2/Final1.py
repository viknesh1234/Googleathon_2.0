from googletrans import Translator
from gtts import gTTS
import os
from moviepy.editor import ImageSequenceClip, AudioFileClip, concatenate_videoclips

VALID_LANGUAGES = ['tamil', 'english', 'french', 'spanish']

def translate_text(text, target_language):
    translator = Translator()

    if target_language.lower() in VALID_LANGUAGES:
        translation = translator.translate(text, dest=target_language.lower())
        return translation.text
    else:
        raise ValueError('Invalid destination language')

def text_to_audio(text, output_file):
    tts = gTTS(text=text, lang='en', slow=False)
    tts.save(output_file)
    return output_file

def get_user_input():
    text_to_translate = input("Enter your news: ")

    target_languages = input("\nEnter the Language (e.g., Tamil,English,French,Spanish - separated by commas): ")
    target_languages = [lang.strip() for lang in target_languages.split(',')]

    return text_to_translate, target_languages

def main():
    text_to_translate, target_languages = get_user_input()

    audio_files = []

    for lang in target_languages:
        try:
            translated_text = translate_text(text_to_translate, lang)

            output_file = f"output_audio_{lang}.mp3"
            audio_files.append(text_to_audio(translated_text, output_file))
        except ValueError as e:
            print(f"Error: {e}")

    images_path = "C:\\Users\\vikne\\Desktop\\Project2\\images1\\"
    output_video_path = r"C:\Project\output_video1.mp4"

    image_files = [f for f in os.listdir(images_path) if f.endswith('.jpg')]

    image_files.sort()

    total_audio_duration = sum(AudioFileClip(audio_file).duration for audio_file in audio_files)

    fps = len(image_files) / total_audio_duration

    clips = [ImageSequenceClip([os.path.join(images_path, image_file)], fps=fps) for image_file in image_files]

    video_clip = concatenate_videoclips(clips, method="compose")

    for lang, audio_file in zip(target_languages, audio_files):
        lang_audio_clip = AudioFileClip(audio_file)
        video_clip = video_clip.set_audio(lang_audio_clip)

    video_clip.write_videofile(output_video_path, codec='mpeg4', audio_codec='mp3', fps=fps)

    os.startfile(output_video_path)

if __name__ == "__main__":
    main()
